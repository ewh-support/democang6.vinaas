<!doctype html>
<html lang="ko">
<head>
	<meta charset="UTF-8" />
	<meta http-equiv="Content-Style-Type" content="text/css" />
	<meta http-equiv="imagetoolbar" content="no" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expries" content="0" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>부산항만공사</title>
	<link type="text/css" href="/_Css/common.css" rel="stylesheet" />
	<link type="text/css" href="/kor/_Css/common.css" rel="stylesheet">
	<link type="text/css" href="/_Css/webfont.css" rel="stylesheet">
</head>

<body class="isSub">
<div class="gap"></div>
<div class="msg-wrap error">
	<p class="tit">서비스 이용에 불편을 드려 죄송합니다.</p>
	<p>잘못된 주소입력, 주소변경, 주소삭제로 접근이 안되시거나, <br>예기치 못한 에러가 발생하여 해당 페이지로 접근이 불가능합니다.</p>
	<p class="mg20t">빠른 시간내로 정상 서비스 하겠습니다.</p>
	
	<div class="c mg40t">
		<a href="javascript:history.back();" class="bp-btn"><span>뒤로가기</span></a>
		<a href="/kor" class="bw-btn mg10"><span>메인으로</span></a>
	</div>
</div>


</body>
</html>


